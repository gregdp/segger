dev_menus = False       # Include under-development menus.
timing = False          # Report execution times for optimizing code.
seggerVersion = '2.3'

from regions import Segmentation, Region, SelectedRegions
