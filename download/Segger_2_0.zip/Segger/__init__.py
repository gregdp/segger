dev_menus = True       # Include under-development menus.
timing = False          # Report execution times for optimizing code.
seggerVersion = '2.0'

from regions import Segmentation, Region, SelectedRegions
