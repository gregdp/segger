
showDevTools = False    # some new also under-development tools
timing = False          # Report execution times for optimizing code.
seggerVersion = '2.9.1'
mapqVersion = '1.8.3'

from regions import Segmentation, Region, SelectedRegions
