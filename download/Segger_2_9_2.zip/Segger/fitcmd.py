

import Segger
import Segger.fit

#import fit

#execfile ( "/Users/greg/Dropbox/_mol/Segger/scripts/fit.py" )
Segger.fit.fitAll ( numProc=6 )

#fit.fitAll ( numProc=6 )
#fit.fitAll ( numProc=1 )
