dev_menus = False       # Include under-development menus.
showDevTools = False    # some new also under-development tools
timing = False          # Report execution times for optimizing code.
seggerVersion = '2.8.0'
mapqVersion = '1.8.0'

from regions import Segmentation, Region, SelectedRegions
