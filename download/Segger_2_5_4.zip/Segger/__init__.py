dev_menus = False       # Include under-development menus.
timing = False          # Report execution times for optimizing code.
showDevTools = False
seggerVersion = '2.5.4'

from regions import Segmentation, Region, SelectedRegions
